<footer class="page-footer">
    <div class="footer-copyright">
        <div class="container">
            &copy; 2024-2025 Dust Studio
        </div>
    </div>
</footer>